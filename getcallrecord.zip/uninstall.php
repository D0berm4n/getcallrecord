<?php
//Johnny Drop Tables
out("Dropping all relevant tables");
$sql = "DROP TABLE `HelloWorld_settings`";
$result = sql($sql);