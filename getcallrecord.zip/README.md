FreePBX HelloWorld
==================

This is boilerplate code for creating a FreePBX module. It is an example of working code, and is installable on a FreePBX system. 

See the file README for license info and additional information.
